Name: Abhigyan Ghosh
Roll No: 20171089
Tokenized text url: `https://drive.google.com/drive/folders/1MbT-TXG-qkznsC3ozTb9Ciln7edgx3eJ?usp=sharing`
How to run the python code: `python3 tokenizer.py <filename>`

