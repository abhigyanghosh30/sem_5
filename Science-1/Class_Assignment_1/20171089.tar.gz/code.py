import math
import random
import operator as op
from functools import reduce
from matplotlib import pyplot as plt

def ncr(n, r):
    r = min(r, n-r)
    numer = reduce(op.mul, range(n, n-r, -1), 1)
    denom = reduce(op.mul, range(1, r+1), 1)
    return numer / denom

def PTheory():
    values = []
    for i in range(1,100):
        values.append(ncr(2*i,i)/math.pow(2,2*i))
    return values

def new_x(x):
    if(random.random()>0.5):
        return x+1
    else:
        return x-1

def player_movement(N):
    player_1 = 0
    player_2 = 0
    for i in range(N):
        player_1 = new_x(player_1)
        player_2 = new_x(player_2)
    if player_1 == player_2:
        return True
    else:
        return False

def simulation(n=10000):
    P = []
    for N in range(1,100):
        count = 0
        for i in range(n):
            if player_movement(N):
                count+=1
        P.append(count/n)
    plt.plot(P)
    plt.ylabel('P(N)')    
    plt.xlabel('N')
    plt.plot(PTheory(),c='y')
    plt.show()


if __name__ == "__main__":
    simulation()

